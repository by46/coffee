import requests
from requests.adapters import HTTPAdapter
from furl import furl

class Client(object):
    def __init__(self, seller_id, access_id, secret_key):
        self.seller_id = seller_id
        self.access_id = access_id
        self.secret_key = secret_key
        self.base = "http://localhost:8080/engine_api"
        session = self.session = requests.session()
        adapter = HTTPAdapter(max_retries=3)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

    def upload(self, public_id, file):
        url = furl(self.base)
        url.path.add(public_id)
        self.session.post(url.url,)
